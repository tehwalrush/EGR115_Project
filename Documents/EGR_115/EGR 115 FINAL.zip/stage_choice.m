function stage_choice(button, event, other_button, nosecone, drag, nose_weight, nose_cost, sim_button, stage1_text, stage2_text, enginebutton2)

ScreenSize = get(groot, 'ScreenSize');
ScreenLength = ScreenSize(3);
ScreenHeight = ScreenSize(4);

button.Value = 1;
other_button.Value = 0;

if strcmp(button.String, "Yes") == 1

    nosecone.Position(4) = 0;
    drag.Position(4) = 0;
    nose_weight.Position(4) = 0;
    nose_cost.Position(4) = 0;
    sim_button.Position(4) = 0;

    stage1_text.Position(4) = 0.04*ScreenLength;
    stage2_text.Position(4) = 0.04*ScreenLength;
    enginebutton2.Position(4) = 0.04*ScreenLength;

elseif strcmp(button.String, "No") == 1

    if strcmp(nose_cost.String, "Nose cone cost: ") == 0
        sim_button.Position(4) = 0.04*ScreenLength;
    else
        sim_button.Position(4) = 0;
    end
    
    nosecone.Position(4) = 0.2;
    drag.Position(4) = 0.03*ScreenHeight;
    nose_weight.Position(4) = 0.03*ScreenHeight;
    nose_cost.Position(4) = 0.03*ScreenHeight;

    stage1_text.Position(4) = 0;
    stage2_text.Position(4) = 0;
    enginebutton2.Position(4) = 0;
end